﻿#region

using System;

#endregion

namespace 职责链模式_请假_职责链模式 {
    internal class Program {
        private static void Main(string[] args) {
            var pm = new ProjectManager("PM");
            var dm = new DepartmentManager("DM");
            var gm = new GeneralManager("GM");
            var ceo = new CEOManager("CEO");

//            pm.Superior = dm;
//            dm.Superior = gm;
//            gm.Superior = ceo;

            pm.Superior = ceo;
            ceo.Superior = dm;

            var r1 = new Request("小明", "请假", "表弟结婚", 1);
            ceo.HandleRequest(r1);
            Console.WriteLine("-------------------------------------");

            var r2 = new Request("小明", "请假", "表弟结婚", 4);
            pm.HandleRequest(r2);
            Console.WriteLine("-------------------------------------");

            var r3 = new Request("小明", "请假", "表弟结婚", 6);
            pm.HandleRequest(r3);
            Console.WriteLine("-------------------------------------");

            var r4 = new Request("小明", "加薪", "物价上涨太快", 500);
            pm.HandleRequest(r4);
            Console.WriteLine("-------------------------------------");

            var r5 = new Request("小明", "加薪", "物价上涨太快", 1000);
            pm.HandleRequest(r5);
            Console.WriteLine("-------------------------------------");

            var r6 = new Request("小明", "请假", "表弟结婚", 15);
            pm.HandleRequest(r6);
            Console.WriteLine("-------------------------------------");

            Console.ReadLine();
        }
    }
}