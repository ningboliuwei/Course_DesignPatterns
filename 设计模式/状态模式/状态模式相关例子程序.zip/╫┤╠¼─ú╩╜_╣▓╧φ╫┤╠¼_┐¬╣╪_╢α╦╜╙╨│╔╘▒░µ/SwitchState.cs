﻿namespace 状态模式_共享状态_开关_多私有成员版 {
    public abstract class SwitchState {
        public abstract void Press(Switch s);
    }
}