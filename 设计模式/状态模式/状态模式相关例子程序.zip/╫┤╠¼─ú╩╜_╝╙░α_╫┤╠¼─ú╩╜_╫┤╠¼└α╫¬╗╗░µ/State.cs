﻿namespace 状态模式_加班_状态模式_状态类转换版 {
    public abstract class State {
        public abstract void Coding(Work work);
    }
}