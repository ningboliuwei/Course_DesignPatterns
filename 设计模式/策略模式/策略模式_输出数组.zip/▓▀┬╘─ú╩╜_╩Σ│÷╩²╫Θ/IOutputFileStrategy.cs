﻿namespace 策略模式_输出数组 {
    internal interface IOutputFileStrategy {
        void OutputFile(string[] data);
    }
}