namespace 命令模式_遥控器;

public class GarageDoor {
    public void Down() {
        Console.WriteLine("车库门降下了");
    }

    public void Up() {
        Console.WriteLine("车库门升起了");
    }
}