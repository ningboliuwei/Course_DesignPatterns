namespace 命令模式_遥控器;

public class Light {
    public void Off() {
        Console.WriteLine("电灯关闭了");
    }

    public void On() {
        Console.WriteLine("电灯打开了");
    }
}