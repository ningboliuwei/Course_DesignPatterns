namespace 迭代器模式_电视机机顶盒迭代器模式;

public class Channel {
    public string ChannelName { get; set; }
    public int ChannelNumber { get; set; }
}